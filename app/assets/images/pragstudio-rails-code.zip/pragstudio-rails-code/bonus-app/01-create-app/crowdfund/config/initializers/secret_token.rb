# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Crowdfund::Application.config.secret_key_base = 'd45c21a4684f66b0d3e4849266b0e644324cb89c5a248f5f87967b8d831149f38b8bb34c5ee73497bbbf9006b6286a9c4d19d5241f15c3548f0a5f8a49cd1bc6'

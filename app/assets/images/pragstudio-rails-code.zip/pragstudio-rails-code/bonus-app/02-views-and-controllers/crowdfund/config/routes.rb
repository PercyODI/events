Crowdfund::Application.routes.draw do
  get "projects" => "projects#index"
end
